# BioQuest Indonesia — Python / Vercel

BioQuest is a Flask + PostgreSQL application based on the supplied green/white mobile biodiversity design. It includes separate user and researcher experiences, mandatory researcher TOTP MFA, role controls, CSRF protection, login throttling, secure cookies, CSP/HSTS/security headers, audit logging, private-media quarantine, and **no ML/model training**.

## Fast Vercel deployment

1. Upload this folder to a **private GitHub repository** and import it into Vercel.
2. In the Vercel project, open **Storage** and connect a Neon Postgres database. Ensure its connection string is available as `DATABASE_URL`.
3. In Vercel **Settings → Environment Variables**, add `APP_ENV=production`, a long random `SECRET_KEY`, a different long random `IP_HASH_PEPPER`, and the three `BOOTSTRAP_RESEARCHER_*` values from `.env.example`.
4. Deploy. **Do not run SQL manually.** On first request BioQuest creates/updates its PostgreSQL tables automatically using `db/schema.sql`, protected by a PostgreSQL advisory lock.
5. Sign in with the bootstrap researcher account. The app requires authenticator-app MFA setup before researcher access is granted.
6. Once that account exists, delete `BOOTSTRAP_RESEARCHER_PASSWORD` from Vercel and redeploy. This removes the bootstrap credential from the runtime configuration.

The core app can now run with accounts and PostgreSQL. Uploads intentionally remain unavailable until private object storage is configured; the application does not fall back to public/local storage.

## Enable secure uploads

Connect a private S3-compatible bucket such as Cloudflare R2 or AWS S3 and add the `S3_*` environment variables. Public bucket access must remain disabled. Configure CORS only for your exact production Vercel origin and the required upload headers/methods.

For a public launch, connect an external malware-scanning worker/service to the quarantine bucket. Vercel serverless functions are not an appropriate place to run a persistent ClamAV daemon. BioQuest's policy is fail-closed: media is quarantined and cannot be viewed by researchers unless `scan_status` is `clean`.

## Security model

Public registration can create only `user` accounts. Researcher access cannot be self-selected. Researchers require password + TOTP MFA. Passwords use Werkzeug scrypt hashing. Mutating API calls require CSRF tokens. Repeated login attempts are throttled. Sensitive actions are audit logged. Media access is authorization-checked and uses short-lived signed URLs. Unscanned/quarantined files are blocked. HTTP responses include restrictive CSP, clickjacking, MIME-sniffing, referrer, permissions and production HSTS controls.

Keep `.env` and all credentials out of Git. `.gitignore` is included.

## Health check

`/api/health` reports whether PostgreSQL and private storage are configured without exposing credentials.


## Camera and Indonesia map
On HTTPS (Vercel), **Take photo** opens the device camera where supported; **Choose photo or video** opens the native picker. Users can optionally request geolocation and separately opt in to sharing an approximate map position. Only verified, clean, opted-in, non-sensitive observations are returned by `/api/map`. Pins update from PostgreSQL when the map is reopened. Leaflet uses OpenStreetMap tiles and visible attribution. Browser camera behavior varies by device.

**Important:** This is not a zero-configuration public launch. You must connect Neon PostgreSQL, private S3-compatible storage, and a real external malware-scanning worker. Uploads remain quarantined until scanned; do not set a flag to skip scanning. Store uploaded media in the private bucket, not in PostgreSQL: PostgreSQL stores ownership, metadata, coordinates, scan and verification state. Researchers need MFA. Before inviting the public, security-review and load-test the app and configure abuse controls and backups.
