import os, re, uuid, secrets, hashlib, base64, io, subprocess, tempfile
from datetime import timedelta
from functools import wraps
from flask import Flask, render_template, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
import psycopg
from psycopg.rows import dict_row
import boto3, pyotp, qrcode
from botocore.config import Config

app=Flask(__name__)
app.config.update(SECRET_KEY=os.getenv('SECRET_KEY',secrets.token_hex(32)),SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SECURE=os.getenv('APP_ENV')=='production',SESSION_COOKIE_SAMESITE='Lax',PERMANENT_SESSION_LIFETIME=timedelta(hours=8),MAX_CONTENT_LENGTH=256*1024)
if os.getenv('APP_ENV')=='production' and (not os.getenv('SECRET_KEY') or not os.getenv('DATABASE_URL')): raise RuntimeError('Production requires SECRET_KEY and DATABASE_URL')

_schema_ready=False
def ensure_schema():
    global _schema_ready
    if _schema_ready:return
    schema_path=os.path.join(os.path.dirname(__file__),'db','schema.sql')
    with psycopg.connect(os.environ['DATABASE_URL'],connect_timeout=8) as conn:
        with conn.cursor() as cur:
            cur.execute('SELECT pg_advisory_lock(78421931)')
            try:
                cur.execute(open(schema_path,encoding='utf-8').read())
                email=os.getenv('BOOTSTRAP_RESEARCHER_EMAIL','').strip().lower();pw=os.getenv('BOOTSTRAP_RESEARCHER_PASSWORD','');name=os.getenv('BOOTSTRAP_RESEARCHER_NAME','Lead Researcher').strip()[:80] or 'Lead Researcher'
                if email and len(pw)>=14:
                    cur.execute("INSERT INTO users(email,name,password_hash,role) VALUES(%s,%s,%s,'researcher') ON CONFLICT(email) DO NOTHING",(email,name,generate_password_hash(pw,method='scrypt')))
            finally:
                cur.execute('SELECT pg_advisory_unlock(78421931)')
    _schema_ready=True

@app.before_request
def initialize_database():
    if request.path!='/api/health': ensure_schema()

def db(): return psycopg.connect(os.environ['DATABASE_URL'],row_factory=dict_row,connect_timeout=8)
def query(sql,params=(),one=False):
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute(sql,params)
            if cur.description:return cur.fetchone() if one else cur.fetchall()
def fail(m,s=400):return jsonify(error=m),s
def audit(action,target=''):
    try: query('INSERT INTO audit_log(actor_id,action,target_id) VALUES(%s,%s,%s)',(session.get('uid'),action,str(target)))
    except Exception: pass
def require(role=None,mfa=False):
    def deco(fn):
        @wraps(fn)
        def inner(*a,**k):
            if not session.get('uid'):return fail('Sign in required',401)
            if role and session.get('role')!=role:return fail('Forbidden',403)
            if mfa and not session.get('mfa_ok'):return fail('MFA required',403)
            return fn(*a,**k)
        return inner
    return deco
@app.before_request
def csrf():
    if request.method in ('POST','PUT','PATCH','DELETE') and request.path.startswith('/api/'):
        if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),session.get('csrf','not-set')):return fail('Invalid CSRF token',403)
@app.after_request
def headers(r):
    for k,v in {'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','Permissions-Policy':'camera=(self), microphone=(), geolocation=(self)','Content-Security-Policy':"default-src 'self'; script-src 'self' https://unpkg.com; style-src 'self' https://unpkg.com; img-src 'self' data: blob: https://tile.openstreetmap.org https://unpkg.com; connect-src 'self' https:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",'Cross-Origin-Opener-Policy':'same-origin','Cross-Origin-Resource-Policy':'same-origin'}.items():r.headers[k]=v
    r.headers['Cache-Control']='no-store' if request.path.startswith('/api/') else 'private, max-age=0'
    if os.getenv('APP_ENV')=='production':r.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains; preload'
    return r
@app.get('/')
def index():session.setdefault('csrf',secrets.token_urlsafe(32));return render_template('index.html')
@app.get('/api/session')
def current():
    session.setdefault('csrf',secrets.token_urlsafe(32));u=None
    if session.get('uid'):u={'id':session['uid'],'name':session['name'],'role':session['role'],'mfa_ok':session.get('mfa_ok',False)}
    return jsonify(csrf=session['csrf'],user=u,pending_mfa=bool(session.get('pending_uid')))
@app.post('/api/register')
def register():
    d=request.get_json(silent=True) or {};email=str(d.get('email','')).strip().lower();name=str(d.get('name','')).strip();pw=str(d.get('password',''))
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or not 2<=len(name)<=80 or len(pw)<14 or len(pw)>256:return fail('Use a valid name/email and a password of at least 14 characters')
    try:r=query('INSERT INTO users(email,name,password_hash,role) VALUES(%s,%s,%s,%s) RETURNING id,name,role',(email,name,generate_password_hash(pw,method='scrypt'),'user'),True)
    except psycopg.errors.UniqueViolation:return fail('Account already exists',409)
    session.clear();session.update(uid=str(r['id']),name=r['name'],role='user',mfa_ok=True,csrf=secrets.token_urlsafe(32));audit('account.register');return jsonify(user={'name':r['name'],'role':'user','mfa_ok':True},csrf=session['csrf']),201
@app.post('/api/login')
def login():
    d=request.get_json(silent=True) or {};email=str(d.get('email','')).strip().lower();pw=str(d.get('password',''));ip=hashlib.sha256((request.headers.get('x-forwarded-for',request.remote_addr or 'unknown').split(',')[0]+os.getenv('IP_HASH_PEPPER','')).encode()).hexdigest()
    n=query("SELECT count(*) n FROM login_attempts WHERE (ip_hash=%s OR email=%s) AND created_at>now()-interval '15 minutes'",(ip,email),True)['n']
    if n>=8:return fail('Too many attempts. Try again later.',429)
    u=query('SELECT id,name,role,password_hash,mfa_enabled,mfa_secret FROM users WHERE email=%s AND active=true',(email,),True);ok=bool(u and check_password_hash(u['password_hash'],pw));query('INSERT INTO login_attempts(ip_hash,email,success) VALUES(%s,%s,%s)',(ip,email,ok))
    if not ok:return fail('Invalid credentials',401)
    session.clear();session['csrf']=secrets.token_urlsafe(32)
    if u['role']=='researcher':
        session.update(pending_uid=str(u['id']),pending_name=u['name'],pending_role=u['role']);return jsonify(mfa_required=True,mfa_setup=not u['mfa_enabled'],csrf=session['csrf'])
    session.update(uid=str(u['id']),name=u['name'],role=u['role'],mfa_ok=True);audit('account.login');return jsonify(user={'name':u['name'],'role':u['role'],'mfa_ok':True},csrf=session['csrf'])
@app.get('/api/mfa/setup')
def mfa_setup():
    uid=session.get('pending_uid');
    if not uid:return fail('Researcher sign-in required',401)
    u=query('SELECT email,mfa_enabled,mfa_secret FROM users WHERE id=%s',(uid,),True)
    if u['mfa_enabled']:return fail('MFA already configured',409)
    secret=u['mfa_secret'] or pyotp.random_base32();query('UPDATE users SET mfa_secret=%s WHERE id=%s',(secret,uid));uri=pyotp.TOTP(secret).provisioning_uri(name=u['email'],issuer_name='BioQuest Indonesia');img=qrcode.make(uri);buf=io.BytesIO();img.save(buf,format='PNG')
    return jsonify(qr='data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode(),secret=secret)
@app.post('/api/mfa/verify')
def mfa_verify():
    uid=session.get('pending_uid');code=str((request.get_json(silent=True) or {}).get('code','')).replace(' ','')
    if not uid:return fail('Researcher sign-in required',401)
    u=query('SELECT id,name,role,mfa_secret,mfa_enabled FROM users WHERE id=%s AND active=true',(uid,),True)
    if not u or not u['mfa_secret'] or not pyotp.TOTP(u['mfa_secret']).verify(code,valid_window=1):return fail('Invalid authentication code',401)
    query('UPDATE users SET mfa_enabled=true,last_login_at=now() WHERE id=%s',(uid,));csrf=session['csrf'];session.clear();session.update(uid=str(u['id']),name=u['name'],role=u['role'],mfa_ok=True,csrf=csrf);audit('account.mfa_login');return jsonify(user={'name':u['name'],'role':u['role'],'mfa_ok':True},csrf=csrf)
@app.post('/api/logout')
def logout():audit('account.logout');session.clear();return jsonify(ok=True)

def s3():return boto3.client('s3',endpoint_url=os.environ['S3_ENDPOINT'],aws_access_key_id=os.environ['S3_ACCESS_KEY_ID'],aws_secret_access_key=os.environ['S3_SECRET_ACCESS_KEY'],region_name=os.getenv('S3_REGION','auto'),config=Config(signature_version='s3v4'))
@app.get('/api/observations')
@require()
def observations():
    if session['role']=='researcher':rows=query("SELECT o.id,o.species,o.notes,o.status,o.scan_status,o.created_at,o.media_type,u.name contributor FROM observations o JOIN users u ON u.id=o.user_id WHERE o.status<>'uploading' ORDER BY o.created_at DESC LIMIT 100")
    else:rows=query("SELECT id,species,notes,status,scan_status,created_at,media_type FROM observations WHERE user_id=%s AND status<>'uploading' ORDER BY created_at DESC LIMIT 100",(session['uid'],))
    return jsonify(items=rows)
@app.post('/api/uploads/prepare')
@require('user')
def prepare():
    d=request.get_json(silent=True) or {};mime=d.get('content_type');size=d.get('size');allowed={'image/jpeg','image/png','image/webp','video/mp4','video/webm'}
    if mime not in allowed or type(size)!=int or not 0<size<=50*1024*1024:return fail('Supported JPG, PNG, WebP, MP4 or WebM up to 50 MB')
    oid=str(uuid.uuid4());key=f"quarantine/{session['uid']}/{oid}";query('INSERT INTO observations(id,user_id,media_key,media_type,media_size,status,scan_status) VALUES(%s,%s,%s,%s,%s,%s,%s)',(oid,session['uid'],key,mime,size,'uploading','pending'))
    url=s3().generate_presigned_url('put_object',Params={'Bucket':os.environ['S3_BUCKET'],'Key':key,'ContentType':mime,'ServerSideEncryption':'AES256'},ExpiresIn=300);return jsonify(id=oid,url=url,method='PUT',content_type=mime)
def scan_object(key):
    # No configuration flag can mark unscanned uploads clean.
    cli=os.getenv('CLAMSCAN_PATH','clamscan')
    try:
        with tempfile.NamedTemporaryFile() as f:
            s3().download_fileobj(os.environ['S3_BUCKET'],key,f);f.flush();r=subprocess.run([cli,'--no-summary',f.name],capture_output=True,timeout=45)
            return 'clean' if r.returncode==0 else ('infected' if r.returncode==1 else 'error')
    except (FileNotFoundError,subprocess.TimeoutExpired):return 'unavailable'
@app.post('/api/observations/<uuid:oid>/complete')
@require('user')
def complete(oid):
    d=request.get_json(silent=True) or {};species=str(d.get('species','')).strip()[:120];notes=str(d.get('notes','')).strip()[:2000];latitude=d.get('latitude');longitude=d.get('longitude');share=bool(d.get('share_location',False));
    if latitude is not None or longitude is not None:
        try: latitude=float(latitude);longitude=float(longitude)
        except (ValueError,TypeError):return fail('Invalid coordinates')
        if not (-11.5<=latitude<=6.5 and 94<=longitude<=142):return fail('Please select a location in Indonesia')
    r=query('SELECT media_key,media_size,media_type,status FROM observations WHERE id=%s AND user_id=%s',(str(oid),session['uid']),True)
    if not r or r['status']!='uploading':return fail('Upload not found',404)
    try:o=s3().head_object(Bucket=os.environ['S3_BUCKET'],Key=r['media_key'])
    except Exception:return fail('Upload not found in private storage',400)
    if o['ContentLength']!=r['media_size'] or o.get('ContentType')!=r['media_type']:return fail('Uploaded file metadata mismatch',400)
    scan=scan_object(r['media_key']);status='pending' if scan=='clean' else 'quarantined';query('UPDATE observations SET species=%s,notes=%s,status=%s,scan_status=%s,latitude=%s,longitude=%s,share_location=%s WHERE id=%s',(species,notes,status,scan,latitude,longitude,share,str(oid)));audit('observation.upload',oid)
    if scan!='clean':return jsonify(ok=True,status='quarantined',message='Upload quarantined until security scanning is available or clears the file.')
    return jsonify(ok=True,status='pending')
@app.get('/api/observations/<uuid:oid>/media')
@require()
def media(oid):
    r=query('SELECT media_key,user_id,status,scan_status FROM observations WHERE id=%s',(str(oid),),True)
    if not r or r['scan_status']!='clean' or r['status'] in ('uploading','quarantined') or (session['role']!='researcher' and str(r['user_id'])!=session['uid']):return fail('Not found',404)
    return jsonify(url=s3().generate_presigned_url('get_object',Params={'Bucket':os.environ['S3_BUCKET'],'Key':r['media_key']},ExpiresIn=60))
@app.post('/api/observations/<uuid:oid>/review')
@require('researcher',mfa=True)
def review(oid):
    d=request.get_json(silent=True) or {};status=d.get('status');species=str(d.get('species','')).strip()[:120]
    if status not in ('verified','rejected'):return fail('Invalid review decision')
    with db() as conn:
        with conn.cursor() as c:
            c.execute("UPDATE observations SET status=%s,species=CASE WHEN %s<>'' THEN %s ELSE species END,reviewer_id=%s,reviewed_at=now() WHERE id=%s AND status='pending' AND scan_status='clean' RETURNING id",(status,species,species,session['uid'],str(oid)))
            if not c.fetchone():return fail('Reviewable observation not found',404)
            c.execute('INSERT INTO audit_log(actor_id,action,target_id) VALUES(%s,%s,%s)',(session['uid'],'observation.'+status,str(oid)))
    return jsonify(ok=True)
@app.get('/api/map')
@require()
def map_points():
    rows=query("SELECT id,species,round(latitude::numeric,1) AS latitude,round(longitude::numeric,1) AS longitude,created_at FROM observations WHERE status='verified' AND scan_status='clean' AND share_location=true AND latitude IS NOT NULL AND longitude IS NOT NULL AND sensitive_location=false ORDER BY created_at DESC LIMIT 500")
    return jsonify(items=rows)

@app.get('/api/health')
def health():
    db_ok=False
    try:
        ensure_schema();query('SELECT 1');db_ok=True
    except Exception:pass
    storage_ok=all(os.getenv(k) for k in ('S3_ENDPOINT','S3_BUCKET','S3_ACCESS_KEY_ID','S3_SECRET_ACCESS_KEY'))
    scanner='clamav-if-installed; otherwise quarantine pending external scanner'
    return jsonify(status='ok' if db_ok else 'degraded',database=db_ok,private_storage=storage_ok,malware_scanner=scanner)

if __name__=='__main__':app.run(debug=os.getenv('APP_ENV')!='production')
