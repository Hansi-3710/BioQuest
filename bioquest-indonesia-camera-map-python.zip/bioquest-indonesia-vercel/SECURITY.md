# BioQuest Security

## Implemented
- Public registration can only create `user` accounts. Researcher role is admin-promoted.
- Researcher login requires TOTP MFA; first researcher login provisions an authenticator secret.
- Passwords are hashed with Werkzeug scrypt. Sessions are HttpOnly, Secure in production, SameSite=Lax and server-signed.
- CSRF tokens protect state-changing API routes; CSP, HSTS, frame denial, MIME sniffing protection, referrer and permissions policies are set.
- Login attempts are rate-limited by hashed IP/email. IP hashing can be peppered with `IP_HASH_PEPPER`.
- Media uses private S3-compatible storage and short-lived signed URLs. Uploads enter a `quarantine/` namespace and are inaccessible to researchers unless `scan_status=clean`.
- ClamAV scanning is supported when the runtime provides `clamscan`. Scan failure/unavailability fails closed and leaves media quarantined.
- Researcher review requires both researcher role and completed MFA. Review/auth events are audit logged.
- Upload MIME types and sizes are allow-listed and object metadata is checked after upload.

## Vercel malware scanning
Vercel serverless functions are not an appropriate place to install/run a persistent ClamAV daemon. For a public Vercel deployment, connect the quarantine bucket to an external malware-scanning worker/service that updates `scan_status` to `clean` only after scanning. Until then, keep `MALWARE_SCAN_MODE=clamav`; if ClamAV is unavailable, uploads remain quarantined instead of being exposed.

## Production checklist
Use a private bucket with public access disabled, database TLS, separate production secrets, least-privilege storage credentials, database backups/PITR, dependency/security monitoring, researcher offboarding, and log retention. Consider verified-email/password-reset delivery and WebAuthn/passkeys before a large public launch.
